# DATABOI 3030Python Challenge - 
30 Days, 30 Mins of Python. An <a href="https://www.youtube.com/playlist?list=PLd-Pc7_mAvogoSREuT_RVgCaxLBAJjNAx" title="Learn Python Data Analysis">Intro to data analysis with Python in Pandas</a>. All the Video Tutorials are available on YouTube got to <a href="http://databoi.com" title="Learn Python Data Analysis">databoi.com</a> and you'll be redirected.
